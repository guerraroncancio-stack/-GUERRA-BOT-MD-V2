import axios from 'axios';
import FormData from 'form-data';

const KEYS = [
    process.env.GEMINI_API_KEY || 'AQ.Ab8RN6Ixd32dRsGatF4cQ7Evm8w9X979iliDiVR-ch63_jdpMg',
    'AQ.Ab8RN6LJqKhPzhy1pUOyvjc0BOG5eoAdu06SzkYtZ7VQ547DFA'
];

const sessions = new Map();

async function requestGemini(payload, keyIndex = 0) {
    if (keyIndex >= KEYS.length) throw new Error('ERR_KEYS_EXHAUSTED');
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${KEYS[keyIndex]}`;
    try {
        return await axios.post(url, payload, {
            headers: { 'Content-Type': 'application/json' },
            timeout: 30000
        });
    } catch (error) {
        if (error.response?.status === 429 || error.response?.status === 400) {
            return requestGemini(payload, keyIndex + 1);
        }
        throw error;
    }
}

const geminiCommand = {
    name: 'gemini',
    alias: ['alex', 'ia'],
    category: 'ai',
    run: async (m, { conn, text }) => {
        let q = m.quoted ? m.quoted : m;
        let mime = (q.msg || q).mimetype || '';
        const prompt = text?.trim();

        if (!prompt && !mime) {
            return await conn.sendMessage(m.chat, { 
                text: `> *✎ Hola, soy Alex-AI. ¿En qué puedo ayudarte hoy?*` 
            }, { quoted: m });
        }

        await m.react('✨');

        try {
            const userId = m.sender;
            const pLow = prompt ? prompt.toLowerCase() : "";
            
            if (/(haz|genera|dibuja|pinta|imagine)/i.test(pLow) && prompt) {
                const setup = {
                    cipher: 'hbMcgZLlzvghRlLbPcTbCpfcQKM0PcU0zhPcTlOFMxBZ1oLmruzlVp9remPgi0QWP0QW',
                    dec(t, s) { return [...t].map(c => /[a-z]/.test(c) ? String.fromCharCode((c.charCodeAt(0) - 97 - s + 26) % 26 + 97) : /[A-Z]/.test(c) ? String.fromCharCode((c.charCodeAt(0) - 65 - s + 26) % 26 + 65) : c).join(''); }
                };
                const token = setup.dec(setup.cipher, 3);
                const form = new FormData();
                form.append('prompt', prompt);
                form.append('token', token);

                try {
                    const imgRes = await axios.post('https://text2video.aritek.app/text2img', form, {
                        headers: { 'user-agent': 'NB Android/1.0.0', 'authorization': token, ...form.getHeaders() },
                        timeout: 15000
                    });

                    if (imgRes.data && imgRes.data.url) {
                        await m.react('🖼️');
                        return await conn.sendMessage(m.chat, { 
                            image: { url: imgRes.data.url }, 
                            caption: `✅ Imagen generada con éxito.`,
                contextInfo: {
                    ...channelInfo
               }
                        }, { quoted: m });
                    }
                } catch (e) {}
            }

            const historial = sessions.get(userId) || [];
            const fechaTexto = new Date().toLocaleDateString('es-ES', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
            
            const contents = [
                { role: 'user', parts: [{ text: `Hoy es ${fechaTexto}. Eres Alex, una IA desarrollada por Deylin. Responde de forma concisa y amigable usando formato de WhatsApp.` }] },
                { role: 'model', parts: [{ text: "Entendido." }] },
                ...historial.map(h => ({ role: h.role, parts: [{ text: h.text }] }))
            ];

            const currentParts = [{ text: prompt || "Analiza este archivo" }];
            
            if (mime && /image|video|audio|pdf|text/.test(mime)) {
                const media = await q.download();
                if (media) {
                    currentParts.push({ 
                        inline_data: { 
                            mime_type: mime, 
                            data: media.toString('base64') 
                        } 
                    });
                }
            }

            contents.push({ role: 'user', parts: currentParts });

            const { data } = await requestGemini({ contents });
            const reply = data?.candidates?.[0]?.content?.parts?.[0]?.text || "No pude procesar la solicitud.";

            historial.push({ role: 'user', text: prompt || "(Archivo)" }, { role: 'model', text: reply });
            sessions.set(userId, historial.slice(-10));

            await m.react('📚');
            await conn.sendMessage(m.chat, { 
                text: reply.replace(/\*\*/g, '*'),
                contextInfo: {
                    ...channelInfo
               }
       }, { quoted: m });

        } catch (err) {
            console.error(err);
            await m.react('🚫');
            await conn.sendMessage(m.chat, { text: `*⚠️ ERROR EN NÚCLEO ALEX*` }, { quoted: m });
        }
    }
};

export default geminiCommand;
