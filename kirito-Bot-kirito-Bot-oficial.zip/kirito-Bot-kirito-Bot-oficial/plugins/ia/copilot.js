import WebSocket from 'ws';
import fetch from 'node-fetch';
import axios from 'axios';

const sessions = new Map();

class Copilot {
    constructor() {
        this.conversationId = null;
        this.foundMedia = [];
        this.headers = {
            'origin': 'https://copilot.microsoft.com',
            'user-agent': 'Mozilla/5.0 (Linux; Android 15; SM-F958 Build/AP3A.240905.015) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.86 Mobile Safari/537.36',
            'content-type': 'application/json'
        };
    }

    async createConversation() {
        const res = await fetch('https://copilot.microsoft.com/c/api/conversations', {
            method: 'POST',
            headers: this.headers
        });
        if (!res.ok) throw new Error(`Error: ${res.status}`);
        const data = await res.json();
        this.conversationId = data.id;
        return this.conversationId;
    }

    async chat(message, sessionId = 'default') {
        if (!this.conversationId) await this.createConversation();
        if (!sessions.has(sessionId)) sessions.set(sessionId, []);
        const history = sessions.get(sessionId);

        return new Promise((resolve, reject) => {
            const ws = new WebSocket(`wss://copilot.microsoft.com/c/api/chat?api-version=2&features=-,ncedge,edgepagecontext&setflight=-,ncedge,edgepagecontext&ncedge=1`, {
                headers: this.headers
            });

            let responseText = '';
            const timeout = setTimeout(() => {
                if (ws.readyState === WebSocket.OPEN) ws.close();
                reject(new Error('Timeout'));
            }, 50000);

            ws.on('open', () => {
                ws.send(JSON.stringify({
                    event: 'setOptions',
                    supportedFeatures: ['partial-generated-images', 'generated-images', 'visual-search'],
                    supportedCards: ['image', 'main', 'video', 'search-result'],
                    ads: { supportedTypes: ['text'] }
                }));

                const context = history.map(h => `User: ${h.q}\nAI: ${h.a}`).join('\n');
                const systemInstruction = `Actúa como un asistente minimalista para WhatsApp.
Reglas de formato:
1. Usa ÚNICAMENTE un asterisco para negritas (*texto*). NUNCA uses doble asterisco (**).
2. Usa guiones bajos para cursivas (_texto_).
3. No uses encabezados estilo Markdown (#, ##, ###).
4. No uses listas con viñetas de círculo; usa guiones (-) o emojis pequeños.
5. Prohibido dar introducciones como "Aquí tienes la info" o "Claro, yo te ayudo". Responde DIRECTAMENTE a la petición.
6. Mantén el texto limpio, sin ruido visual técnico.`;

const fullPrompt = `${systemInstruction}\n\n${context}\nUser: ${message}`;


                ws.send(JSON.stringify({
                    event: 'send',
                    mode: 'chat',
                    conversationId: this.conversationId,
                    content: [{ type: 'text', text: fullPrompt }],
                    context: {}
                }));
            });

            ws.on('message', (chunk) => {
                try {
                    const parsed = JSON.parse(chunk.toString());

                    if (parsed.event === 'appendText') {
                        responseText += parsed.text || '';
                    }

                    if (parsed.event === 'card') {
                        if (parsed.card?.type === 'image' && parsed.card.images) {
                            parsed.card.images.forEach(img => {
                                if (img.image?.url) this.foundMedia.push({ type: 'image', url: img.image.url });
                            });
                        }
                        if (parsed.card?.type === 'video' && parsed.card.videos) {
                            parsed.card.videos.forEach(vid => {
                                if (vid.source?.url) this.foundMedia.push({ type: 'video', url: vid.source.url });
                            });
                        }
                    }

                    if (parsed.event === 'upsertImageUrl') {
                        this.foundMedia.push({ type: 'image', url: parsed.url });
                    }

                    if (parsed.event === 'done') {
                        clearTimeout(timeout);
                        const cleanText = responseText.trim();
                        history.push({ q: message, a: cleanText });
                        if (history.length > 5) history.shift();

                        resolve({
                            text: cleanText,
                            media: this.foundMedia
                        });
                        ws.close();
                    }
                } catch (e) {}
            });

            ws.on('error', (err) => {
                clearTimeout(timeout);
                reject(err);
            });
        });
    }
}

async function downloadMedia(url, retries = 2) {
    for (let i = 0; i < retries; i++) {
        try {
            const response = await axios.get(url, { responseType: 'arraybuffer', timeout: 10000 });
            return Buffer.from(response.data);
        } catch (e) {
            if (i === retries - 1) return null;
        }
    }
}

async function sendAlbum(conn, jid, mediaList, options = {}) {
    const album = conn.generateWAMessageFromContent(jid, {
        albumMessage: {
            expectedImageCount: mediaList.filter(m => m.type === 'image').length,
            ...(options.quoted ? {
                contextInfo: {
                    stanzaId: options.quoted.key.id,
                    participant: options.quoted.key.participant || options.quoted.key.remoteJid,
                    quotedMessage: options.quoted.message,
                }
            } : {}),
        }
    }, {});

    await conn.relayMessage(jid, album.message, { messageId: album.key.id });

    await Promise.all(mediaList.map(async (item, i) => {
        const buffer = await downloadMedia(item.url);
        if (!buffer) return;

        const mediaType = item.type === 'video' ? { video: buffer } : { image: buffer };
        const msg = await conn.generateWAMessage(jid, {
            ...mediaType,
            ...(i === 0 ? { caption: options.caption || "" } : {})
        }, { upload: conn.waUploadToServer });

        msg.message.messageContextInfo = {
            messageAssociation: { associationType: 1, parentMessageKey: album.key }
        };

        return conn.relayMessage(jid, msg.message, { messageId: msg.key.id });
    }));
}

const copilotCommand = {
    name: 'copilot',
    alias: ['copilot', 'ms'],
    category: 'ai',
    run: async (m, { conn, text }) => {
        if (!text) return conn.sendMessage(m.chat, { text: '¿En qué puedo ayudarte?' }, { quoted: m });

        await m.react('⏳');

        try {
            const copilot = new Copilot();
            const result = await copilot.chat(text, m.sender);

            await m.react('✅');

            if (result.media && result.media.length > 0) {
                await sendAlbum(conn, m.chat, result.media.slice(0, 10), {
                    caption: result.text,
                    quoted: m
                });
            } else {
                await conn.sendMessage(m.chat, { 
                 text: result.text,
                     contextInfo: {
                    ...channelInfo
                    },
                  }, { quoted: m });
            }

        } catch (e) {
            console.error(e);
            await m.react('❌');
            await conn.sendMessage(m.chat, { text: `⚠️ Error: ${e.message}` }, { quoted: m });
        }
    }
};

export default copilotCommand;
