import { jidNormalizedUser } from '@whiskeysockets/baileys';
import { startSubBot } from '../../lib/serbot.js';
import fetch from 'node-fetch';

let videoCache = null;
const VIDEO_URL = 'https://cdn.dix.lat/me/1777480208815.mp4';

const serbot = {
    name: 'serbot',
    alias: ['code', 'subbot', 'jadibot'],
    category: 'main',
    run: async (m, { conn, args, usedPrefix, command }) => {

        const MAX_SUBBOTS = 100;
        const activeCount = global.conns ? global.conns.size : 0;

        if (!videoCache) {
            videoCache = await fetch(VIDEO_URL).then(res => res.buffer()).catch(() => null);
        }

        if (activeCount >= MAX_SUBBOTS) {
            return await conn.sendMessage(m.chat, {
                video: videoCache || { url: VIDEO_URL },
                gifPlayback: true,
                caption: `亗  *CAPACIDAD LLENA* 亗\n\nNo se encontraron espacios disponibles.\n\nhttps://kirito.dix.lat/donations`
            }, { quoted: m });
        }

        const senderId = jidNormalizedUser(m.sender);
        let targetNum = args[0] ? args[0].replace(/[^0-9]/g, '') : senderId.split('@')[0];
        let targetJid = targetNum + '@s.whatsapp.net';

        const instructions = `亗  *KIRITO SERBOT* 亗

༂ꦽ  ① DISPOSITIVOS VINCULADOS
༂ꦽ  ② VINCULAR CON NÚMERO
༂ꦽ  ③ INGRESAR EL CÓDIGO

✰ *SOLICITUD:* @${targetNum}
✰ *CAPACIDAD:* ${activeCount}/${MAX_SUBBOTS}

『───┈┈┈┈┄┄╌╌╌╌┄┄┈┈┈┈───』

⚠ *NOTA:* El código vence en 8 segundos y es único para @${targetNum}
ᰔᩚ *INFO:* Usa \`#reglas-subbot\` para los términos.`;

        await conn.sendMessage(m.chat, {
            video: videoCache || { url: VIDEO_URL },
            gifPlayback: true,
            caption: instructions,
            mentions: [targetJid],
            contextInfo: { ...global.channelInfo }
        }, { quoted: m });

        const code = await startSubBot(m, conn, targetNum, { isCode: false });

        if (code && typeof code === 'string') {
            await conn.sendMessage(m.chat, {
                text: code
            }, { quoted: m });
        }
    }
};

export default serbot;
