import { jidNormalizedUser } from '@whiskeysockets/baileys';
import fetch from 'node-fetch';
import { FormData, Blob } from 'formdata-node';
import { fileTypeFromBuffer } from 'file-type';

const uploadToDeylinApi = async (buffer, fileName, mime) => {
    try {
        const formData = new FormData();
        const blob = new Blob([buffer], { type: mime });
        formData.append('file', blob, fileName);
        const response = await fetch('https://api.dix.lat/upload2', {
            method: 'POST',
            body: formData,
            headers: { 'User-Agent': 'Drive-Client' }
        });
        const json = await response.json();
        return (json.status && json.data) ? json.data : null;
    } catch (e) {
        return null;
    }
};

const settingsSubBot = {
    name: 'settings-subbot',
    alias: ['setnamebot', 'setimgbot', 'setprefix', 'setsystem'],
    category: 'owner',
    run: async (m, { conn, text, command, usedPrefix, isROwner }) => {
        const botJid = jidNormalizedUser(conn.user.id);
        const isMainBot = botJid === jidNormalizedUser(global.conn?.user?.id);

        if (!isROwner && !conn.isSub) return;

        if (isMainBot && !isROwner) {
            return conn.reply(m.chat, '❒ Solo el Desarrollador puede modificar el Bot Principal.', m);
        }

        let settings = await global.SubBotSettings.findOne({ botId: botJid });
        
        if (!settings) {
            settings = await global.SubBotSettings.create({ 
                botId: botJid, 
                botName: 'Kirito', 
                botImage: global.img(), 
                prefix: '.',
                modulos: { bienvenida: true, despedida: true, deteccion: true, antilink: true, antiestatus: true }
            });
        }

        if (!settings.modulos) {
            settings.modulos = { bienvenida: true, despedida: true, deteccion: true, antilink: true, antiestatus: true };
            await settings.save();
        }

        const sendMenu = () => {
            const menu = `┏━━〔 CONFIGURACIÓN 〕━━┓
┃ 
┃ ✎ ${usedPrefix}setnamebot [texto]
┃ ↳ Cambia el nombre del bot.
┃ 
┃ ✎ ${usedPrefix}setimgbot [enlace/mención]
┃ ↳ Cambia la imagen de perfil.
┃ 
┃ ✎ ${usedPrefix}setprefix [carácter]
┃ ↳ Cambia el prefijo (máx 3).
┃ 
┃ ✎ ${usedPrefix}setsystem [módulo]
┃ ↳ Alterna funciones del sistema.
┃ 
┣━━〔 MÓDULOS ACTUALES 〕━━┓
┃ 
┃ [ ${settings.modulos?.bienvenida ? '✓' : '✗'} ] bienvenida
┃ [ ${settings.modulos?.despedida ? '✓' : '✗'} ] despedida
┃ [ ${settings.modulos?.deteccion ? '✓' : '✗'} ] deteccion
┃ [ ${settings.modulos?.antilink ? '✓' : '✗'} ] antilink
┃ [ ${settings.modulos?.antiestatus ? '✓' : '✗'} ] antiestatus
┃ 
┗━━━━━━━━━━━━━━━━━━┛`;
            return conn.reply(m.chat, menu, m);
        };

        if (command === 'settings-subbot' || (command === 'setsystem' && !text)) return sendMenu();

        if (command === 'setnamebot') {
            if (!text) return conn.reply(m.chat, `✎ Ingresa el nuevo nombre.`, m);
            settings.botName = text;
            await settings.save();
            global.subbotConfig[botJid] = settings.toObject();
            conn.settings = global.subbotConfig[botJid];
            await conn.updateProfileStatus(`${text} | Activo`).catch(() => null);
            return conn.reply(m.chat, `✓ Nombre actualizado: ${text}`, m);
        }

        if (command === 'setimgbot') {
            let q = m.quoted ? m.quoted : m;
            let mime = (q.msg || q).mimetype || '';
            let url = text;

            if (/image/.test(mime)) {
                await m.react('🕓');
                let buffer = await q.download();
                const type = await fileTypeFromBuffer(buffer);
                const fileName = `img_${Date.now()}.${type?.ext || 'png'}`;
                const result = await uploadToDeylinApi(buffer, fileName, mime);
                if (!result) {
                    await m.react('✖');
                    return conn.reply(m.chat, '✗ Error al procesar imagen.', m);
                }
                url = result.url;
                await m.react('✓');
            } else if (!/^https?:\/\//.test(text)) {
                return conn.reply(m.chat, '✎ Responde a una imagen o proporciona una URL.', m);
            }

            settings.botImage = url;
            await settings.save();
            global.subbotConfig[botJid] = settings.toObject();
            conn.settings = global.subbotConfig[botJid];
            return conn.reply(m.chat, '✓ Imagen de instancia actualizada.', m);
        }

        if (command === 'setprefix') {
            if (!text || text.length > 3) return conn.reply(m.chat, '✎ Prefijo no válido.', m);
            settings.prefix = text.trim();
            await settings.save();
            global.subbotConfig[botJid] = settings.toObject();
            conn.settings = global.subbotConfig[botJid];
            return conn.reply(m.chat, `✓ Nuevo prefijo: ${text}`, m);
        }

                 if (command === 'setsystem') {
            const modulosValidos = ['bienvenida', 'despedida', 'deteccion', 'antilink', 'antiestatus'];
            const mod = text?.toLowerCase().trim();

            if (!mod || (!modulosValidos.includes(mod) && mod !== 'all')) return sendMenu();

            if (mod === 'all') {
                const algunEncendido = modulosValidos.some(m => settings.modulos[m]);
                const nuevoEstadoGeneral = !algunEncendido;

                const updateData = {};
                modulosValidos.forEach(m => {
                    updateData[`modulos.${m}`] = nuevoEstadoGeneral;
                    settings.modulos[m] = nuevoEstadoGeneral;
                });

                await global.SubBotSettings.updateOne(
                    { botId: botJid },
                    { $set: updateData }
                );

                global.subbotConfig[botJid] = settings.toObject();
                conn.settings = global.subbotConfig[botJid];

                return conn.reply(m.chat, `✓ Todos los módulos han sido: ${nuevoEstadoGeneral ? 'ENCENDIDOS' : 'APAGADOS'}`, m);
            }

            const nuevoEstado = !settings.modulos[mod];
            await global.SubBotSettings.updateOne(
                { botId: botJid },
                { $set: { [`modulos.${mod}`]: nuevoEstado } }
            );

            settings.modulos[mod] = nuevoEstado;
            global.subbotConfig[botJid] = settings.toObject();
            conn.settings = global.subbotConfig[botJid];
            
            return conn.reply(m.chat, `✓ Módulo [${mod}] estado: ${nuevoEstado ? 'ENCENDIDO' : 'APAGADO'}`, m);
        }
    }
};

export default settingsSubBot;
